<?php
/*
Plugin Name: WPShout Taxonomy Image
*/

// Get the term object
$thumbs_up_term = get_term_by('name', 'Thumbs Up!', 'thumbs');

// Get the ID property of the term object
$term_id = $thumbs_up_term->term_id;

// Add meta to the term object
update_term_meta($term_id, 'thumb_default_image', 'https://static1.squarespace.com/static/5b45005b5ffd20a0dc3f7162/t/5b4525140e2e726e6d21e2dc/1536199977155/');

// Get the term object
$thumbs_down_term = get_term_by('name', 'Thumbs Down!', 'thumbs');

// Get the ID property of the term object
$term_id = $thumbs_down_term->term_id;

// Add meta to the term object
update_term_meta($term_id, 'thumb_default_image', 'https://nnimgt-a.akamaihd.net/transform/v1/crop/frm/Vh44R52cnVnpVA5ArWcrmw/a8cfb962-1c5c-4fbb-ad8d-7747479da514.jpg/r4107_0_8800_4732_w1200_h678_fmax.jpg');


function wpshout_add_thumb_image_before_content($content)
{
    // Get array of thumb terms that apply to this post
    $thumb_rating_object_array = get_the_terms(get_the_ID(), 'thumbs');

    // Check that there's at least one term
    if (!(is_array($thumb_rating_object_array) && count($thumb_rating_object_array) > 0)) {
        return $content;
    }

    // Get the ID property of the first thumb term
    $term_id = $thumb_rating_object_array[0]->term_id;

    // Get term meta for the term, formatted as a string
    $thumb_image_src = get_term_meta($term_id, 'thumb_default_image', true);

    // Check that the term meta value is a string with greater than 0 length
    if (!(is_string($thumb_image_src) && strlen($thumb_image_src) > 0)) {
        return $content;
    }

    // Return fetched image before $content
    $img_string = '<img src="' . $thumb_image_src . '">';
    return $img_string . $content;
}
add_filter('the_content', 'wpshout_add_thumb_image_before_content');
